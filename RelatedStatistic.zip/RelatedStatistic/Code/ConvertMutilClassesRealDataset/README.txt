Download : 
https://moa.cms.waikato.ac.nz/datasets/
http://people.vcu.edu/��acano/DE-Rules

Steps:
1. Use Weka GUI convert the arff datasets to csv.
2. Change the label of the last column to Cclass for the csv files.
3. Run tht python code to convert the muti-class datasets to binary datasets.
-BNG_wine	3
-BNG_bridges	'CONT-T'
-BNG_zoo	'amphibian'
-shuttle	4
-poker_lsn	2
-covtype1	1
-covtype3	3
-covtype6	6
4. Use Weka GUI convert the csv to arff