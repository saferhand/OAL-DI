Run the DataScripts.bat to generate synthetic datasets.
Before that, please create the folder contents according to it.