# -*- coding: utf-8 -*-
"""
Created on Tue Aug 21 09:34:02 2018

@author: Zhang Hang
"""
import pandas as pd
df = pd.read_csv('shuttle.csv',encoding='utf-8')
df1 = df
df['class']=df.iloc[:,-1]
df.loc[df.iloc[:,-1] != 4,'class']= 0
df.loc[df.iloc[:,-1] == 4,'class']= 1
del df['Cclass']
df.to_csv('shuttle_b.csv',encoding='utf-8',index=False)