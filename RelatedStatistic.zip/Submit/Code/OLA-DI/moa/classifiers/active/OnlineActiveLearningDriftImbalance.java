/*
 *    OnlineActiveLearningDriftImbalance.java
 *    Copyright (C) 2018 National University of Defense Technology, Changsha, China
 *    @author Zhang Hang (zhanghang13@nudt.edu.cn)
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program. If not, see <http://www.gnu.org/licenses/>.
 *    
 */
package moa.classifiers.active;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import moa.classifiers.AbstractClassifier;
import moa.classifiers.Classifier;
import moa.core.DoubleVector;
import moa.core.Measurement;
import moa.core.ObjectRepository;
import moa.options.ClassOption;
import com.github.javacliparser.FloatOption;
import com.github.javacliparser.IntOption;
import moa.tasks.TaskMonitor;
import com.yahoo.labs.samoa.instances.Instance;
import moa.core.Utils;

/**
 * 
 * 
 */
public class OnlineActiveLearningDriftImbalance extends AbstractClassifier {

	private static final long serialVersionUID = 1L;
	 
    @Override
    public String getPurposeString() {
        return "Online Active Learning Paired Ensemble for Concept Drift with Class Imbalance.";
    }
    
    /**
     * Type of classifier to use as a component classifier.
     */
    public ClassOption learnerOption = new ClassOption("learner", 'l', "Classifier to train.", Classifier.class,
    		"trees.HoeffdingTree");    
    /**
     * Number of component classifiers.
     */
    public IntOption memberCountOption = new IntOption("memberCount",
    		'n', "The maximum number of classifier in an ensemble.", 1, 1, 1);    
    /**
     * Chunk size.
     */
    public IntOption chunkSizeOption = new IntOption("chunkSize",
    		'c', "The chunk size used for classifier creation and evaluation.", 500, 1, Integer.MAX_VALUE);
    
    public FloatOption selectionSizeOption = new FloatOption("selectionSize", 
    		'r',"The percentenge of random selection size.",
    		0.1, 0.0, 0.5);

    public FloatOption fixedThresholdOption = new FloatOption("fixedThreshold",
            'u', "Fixed threshold.",
            0.5, 0.00, 0.5);

    public FloatOption PerofRandOption = new FloatOption("PerofRandOption",
            'p', "Percentenge of random strategy labled .",
            0.01, 0.00, 1.00);
    
    public FloatOption StepOption = new FloatOption("StepOption",
            's', "Threshold adjustment step.",
            0.01, 0.00, 1.00);
    
    public FloatOption StableWeight = new FloatOption("StableWeight",
            'w', "Weight of stable classifier.",
            0.5, 0.00, 1.00);
    
	protected static int numberOfAttributes;         //attribute number
	protected static int numberOfClasses=0;                     //class number

	protected int selectionSize;                    // every time we add selectionSize to train
	protected int currentBaseLearnerNo=-1;          // current Base Learner No.  
  
	public static int iterationControl=0;
	protected  int costLabeling=0;
	protected  int correctcount = 0;
	public  int sumBaseLearners=0; 
	protected  double newThreshold;
	protected Random rd1 = new Random();
    protected  Classifier[] ensemble;

    protected double[] dynamicWeight;

    public static int processedInstances=0;

    protected Classifier candidateClassifier;
    protected static Classifier StableClassifier;

    public static Instance[] currentChunk;
    /**
	 * Class distributions.
	 */
	protected long[] classDistributions;
	protected int[] predictrightclassTP;
	protected int[] predictclass;
	protected int[] classNumbers;
	protected double[] recall;
	protected double[] precision;
	protected double[] fscores;
	protected double[] sizeofclasses;
	protected int[] predictrightclassTPchunk;
	protected int[] predictclasschunk;
	protected int[] classNumberschunk;
	protected double[] recallchunk;
	protected double[] precisionchunk;
	protected double[] fscoreschunk;
	protected double[] sizeofclasseschunk;
	protected double[] sizefscoredynamicweight;
	protected double[] gmeans;
	protected int[] LBEclassNumbers;
	protected double[] LBEthreshold;
	protected double r0; 
	protected double p0; 
	protected double LimbalanceRate;  
	
	public void calculateFscores(Instance instance)
	{
		int classlable = (int)instance.classValue();
		double[] count = getVotesForInstance(instance);
        int maxIndex = Utils.maxIndex(count);
        classNumbers[classlable]++;
        LBEclassNumbers[classlable]++;
        predictclass[maxIndex]++;
        for (int i=0;i<this.memberCountOption.getValue();i++)
        {
        	classNumberschunk[classlable + i*numberOfClasses]++;
        	predictclasschunk[maxIndex + i*numberOfClasses]++;
        }
        if (classlable==maxIndex)
        {
        	predictrightclassTP[classlable]++;
            for (int j=0;j<this.memberCountOption.getValue();j++)
            {
            	predictrightclassTPchunk[classlable + j*numberOfClasses]++;
            }            	
        }
        for (int i=0;i<numberOfClasses;i++)
        {
        	if (classNumbers[i]>0&&predictclass[i]>0&&predictrightclassTP[i]>0){
        		recall[i] = (double)predictrightclassTP[i]/(double)classNumbers[i];
       		    precision[i] = (double)predictrightclassTP[i]/(double)predictclass[i];
        		fscores[i] = 2*(double)precision[i]*(double)recall[i]/((double)precision[i]+(double)recall[i]);
        		sizeofclasses[i] = classNumbers[i]/(double)processedInstances;
    			int TNFP=0;
    			int TN=0;
        		for(int j=0;j<numberOfClasses;j++){
        			TNFP = TNFP + classNumbers[j];
        			TN = TN + predictrightclassTP[j];
        		}
        		TNFP = TNFP - classNumbers[i];
        		TN = TN - predictrightclassTP[i];
        		gmeans[i] = Math.sqrt((double)predictrightclassTP[i]*(double)TN/(double)classNumbers[i]/(double)TNFP);
        	}
            for (int k=0;k<(int)this.memberCountOption.getValue();k++)
            {
            	if (classNumberschunk[i+k*numberOfClasses]>0&&predictclasschunk[i+k*numberOfClasses]>0
            			&&predictrightclassTPchunk[i+k*numberOfClasses]>0){            	
            		recallchunk[i+k*numberOfClasses] = (double)predictrightclassTPchunk[i+k*numberOfClasses]/(double)classNumberschunk[i+k*numberOfClasses];
           		    precisionchunk[i+k*numberOfClasses] = (double)predictrightclassTPchunk[i+k*numberOfClasses]/(double)predictclasschunk[i+k*numberOfClasses];
            		fscoreschunk[i+k*numberOfClasses] = 2*(double)precisionchunk[i+k*numberOfClasses]*(double)recallchunk[i+k*numberOfClasses]/((double)precisionchunk[i+k*numberOfClasses]+(double)recallchunk[i+k*numberOfClasses]);
            		sizeofclasseschunk[i+k*numberOfClasses] = classNumberschunk[i+k*numberOfClasses]/(double)(k*this.chunkSizeOption.getValue());
            	}
            }                 	
        }
        if (iterationControl==0){
            for (int i=0;i<numberOfClasses;i++)
            {
                for (int l = (this.memberCountOption.getValue() - 1);l > 0;l--)
                {
                	classNumberschunk[i+l*numberOfClasses] = classNumberschunk[i+(l-1)*numberOfClasses];
                	predictclasschunk[i+l*numberOfClasses] = predictclasschunk[i+(l-1)*numberOfClasses];
                	predictrightclassTPchunk[i+l*numberOfClasses] = predictrightclassTPchunk[i+(l-1)*numberOfClasses];
                }
                classNumberschunk[i] = 0;
            	predictclasschunk[i] = 0;
            	predictrightclassTPchunk[i] = 0;
            }            
        }
	}
	
	
    @Override
    public void prepareForUseImpl(TaskMonitor monitor, ObjectRepository repository) {

        StableClassifier = ((Classifier) getPreparedClassOption(this.learnerOption)).copy();
        this.ensemble = new Classifier[this.memberCountOption.getValue()];
        this.dynamicWeight = new double[this.memberCountOption.getValue()];
        
        for(int i=0;i<this.memberCountOption.getValue();i++)
        {
        	this.ensemble[i]= ((Classifier) getPreparedClassOption(this.learnerOption)).copy();
        }
        
        super.prepareForUseImpl(monitor, repository);
    }

    @Override
    public void resetLearningImpl() {
        
        StableClassifier.resetLearning();
    	for(int i=0;i<this.memberCountOption.getValue();i++)
        {
        	this.ensemble[i].resetLearning();
        	this.dynamicWeight[i]=0;
        }
        
        selectionSize = (int)(this.selectionSizeOption.getValue()*this.chunkSizeOption.getValue());
        currentChunk = new Instance[this.chunkSizeOption.getValue()];

        newThreshold = (fixedThresholdOption.getValue()*2)/numberOfClasses;
 
        this.r0 = this.selectionSizeOption.getValue();
        this.p0 = this.PerofRandOption.getValue();      
        currentBaseLearnerNo = -1;
        correctcount=0;
        costLabeling=0;
        processedInstances=0;
        iterationControl=0;
        sumBaseLearners=0;
    }

    @Override
    public void trainOnInstanceImpl(Instance inst) 
    {
    	dealInstance( inst) ;    	
    } 
    
    public void dealInstance(Instance inst) 
    {
    	initVariables();
    	Instance instance = currentChunk[iterationControl];		//get instance from the buffer
        int numEnsembledBaseLearners=Math.min(this.memberCountOption.getValue(),sumBaseLearners);
    	////Uncertainty strategy
        if (UncertaintyStrategy(instance))
        { ///label instance and train on it
        	StableClassifier.trainOnInstance(instance);
        	for(int j=0; j<numEnsembledBaseLearners; j++)
        	{
        		ensemble[j].trainOnInstance(instance);
        	}
        	costLabeling++;
        	newThreshold =newThreshold* ((double)1 - StepOption.getValue());
        } 
        else
        {
            if(ImbalanceStrategy(instance))
            {  	///label instance and train on it
            	StableClassifier.trainOnInstance(instance);             	
             	for(int j=0; j<numEnsembledBaseLearners; j++)
             	{
             		ensemble[j].trainOnInstance(instance);
             	}
             	costLabeling++;
            }
        }
        
        processedInstances++;
        //System.out.println(processedInstances);
    	currentChunk[iterationControl]=inst;
        iterationControl=(iterationControl+1)%this.chunkSizeOption.getValue();
        calculateFscores(instance);        
        if(iterationControl==0)
        	createNewBaseLearner();
	}  
    
    public boolean UncertaintyStrategy(Instance instance){
    	double[] count = getVotesForInstance(instance);
        int maxIndex = Utils.maxIndex(count);                       
        double maxDistr=count[maxIndex];
        count[maxIndex]=0;
        int secondMaxIndex = Utils.maxIndex(count);    	        
        double margin = maxDistr-count[secondMaxIndex];  //get EnsembleMargin(instance)
        if (margin <= newThreshold)
        { 
        	newThreshold = newThreshold* ((double)1 - StepOption.getValue());
        	return true;
        } 
        else
        {
        	return false;
        }
    }
    
    public boolean ImbalanceStrategy(Instance instance){
    	double[] count = getVotesForInstance(instance);     
    	int maxIndex = Utils.maxIndex(count);                        	   	
    	if(rd1.nextDouble() < LBEthreshold[maxIndex])
        {
    		return true;
        } 
        else
        {
        	return false;
        }
    }
    
    public void createNewBaseLearner() {
    	int labeled = 0;
    	int maxIndex,minIndex;
    	Random rd2 = new Random();
    	boolean[] selected = new boolean[this.chunkSizeOption.getValue()];
        sumBaseLearners++;
        currentBaseLearnerNo=(currentBaseLearnerNo+1)%this.memberCountOption.getValue();//dynamic classifier replacement
        ensemble[currentBaseLearnerNo].resetLearning();
        dynamicWeight[currentBaseLearnerNo]=0;
        
        initVariables();
        
        if(sumBaseLearners>1){
        	maxIndex = Utils.maxIndex(LBEclassNumbers);
        	minIndex = Utils.minIndex(LBEclassNumbers);
        	LimbalanceRate = LBEclassNumbers[minIndex] > 0 ? LBEclassNumbers[minIndex]/LBEclassNumbers[maxIndex] : 0.00001;
        	if(LimbalanceRate < this.p0){
        		this.selectionSizeOption.setValue(this.selectionSizeOption.getValue()+(this.PerofRandOption.getValue()-LimbalanceRate)/2);  ///r+(p-q)/2
        		selectionSize = (int)(this.selectionSizeOption.getValue()*this.chunkSizeOption.getValue());
        		this.PerofRandOption.setValue(LimbalanceRate);	
        	}
        	else if(LimbalanceRate >= this.p0){
        		this.selectionSizeOption.setValue(this.r0);  ///r=r0
        		selectionSize = (int)(this.selectionSizeOption.getValue()*this.chunkSizeOption.getValue());
        		this.PerofRandOption.setValue(this.p0);
        	}
        }

        while(labeled < selectionSize)
        {
        	int no = (int)(rd2.nextFloat() * this.chunkSizeOption.getValue());
        	
        	if(!selected[no]){
       			StableClassifier.trainOnInstance(currentChunk[no]);
       			ensemble[currentBaseLearnerNo].trainOnInstance(currentChunk[no]);
       			selected[no] = true;
       			labeled++;     			
       		}
       	}//End while

        for (int k = 0; k < numberOfClasses; k++){        	
        	if (LBEclassNumbers[k] > 0){
        		LBEthreshold[k]=(PerofRandOption.getValue()*this.chunkSizeOption.getValue())/(LBEclassNumbers[k]*numberOfClasses);
        	}
        	else{
        		LBEthreshold[k] = 1.00;    ///PerofRandOption.getValue();
        	}
        	LBEclassNumbers[k]=0;
        }       
        
        
       dynamicWeight[0] = 0.5;
       costLabeling+=labeled;
       newThreshold = (fixedThresholdOption.getValue()*2)/numberOfClasses;

    }  


    public void dealLastChunk()
    {
    	if(sumBaseLearners==0) // can not create stableLearner
    		return;
    	for(int i=0;i<this.chunkSizeOption.getValue();i++)
    	{
        	Instance inst = currentChunk[i];
    		dealInstance( inst);
    	}
    	
    }


    /**
     * Initiates  class distribution variables.
     */
    private void initVariables()
    {

        if (this.classDistributions == null) {
            this.classDistributions = new long[this.getModelContext().classAttribute().numValues()];

            for (int i = 0; i < this.classDistributions.length; i++) {
                this.classDistributions[i] = 0;
            }
            numberOfClasses = this.getModelContext().classAttribute().numValues();
            numberOfAttributes = this.getModelContext().numAttributes();
        }
        
        
        if (this.predictclass == null ) {
        	this.predictclass = new int[numberOfClasses];
        	this.predictrightclassTP = new int[numberOfClasses];
        	this.classNumbers = new int[numberOfClasses];
        	this.recall = new double[numberOfClasses];
        	this.precision = new double[numberOfClasses];
        	this.fscores = new double[numberOfClasses];
        	this.sizeofclasses = new double[numberOfClasses];
        	this.LBEclassNumbers = new int[numberOfClasses];
        	this.LBEthreshold = new double[numberOfClasses];
        	this.predictrightclassTPchunk = new int[numberOfClasses*this.memberCountOption.getValue()];
        	this.predictclasschunk = new int[numberOfClasses*this.memberCountOption.getValue()];
        	this.classNumberschunk = new int[numberOfClasses*this.memberCountOption.getValue()];
        	this.recallchunk = new double[numberOfClasses*this.memberCountOption.getValue()];
        	this.precisionchunk = new double[numberOfClasses*this.memberCountOption.getValue()];
        	this.fscoreschunk = new double[numberOfClasses*this.memberCountOption.getValue()];
        	this.sizeofclasseschunk = new double[numberOfClasses*this.memberCountOption.getValue()];

        	this.sizefscoredynamicweight = new double[this.memberCountOption.getValue()];
        	this.gmeans = new double[numberOfClasses];       	
	        for (int j = 0; j < numberOfClasses; j++)
	        {
	        	this.predictrightclassTP[j]=0;
	        	this.predictclass[j]=0;
	        	this.classNumbers[j]=0;
	        	this.recall[j]=0;
	        	this.precision[j]=0;
	        	this.fscores[j]=0;
	        	this.sizeofclasses[j]=0;	        	
	        	this.gmeans[j]=0;
	        	this.LBEclassNumbers[j]=0;
	        	this.LBEthreshold[j]=0;
	        }

	        for (int k=0; k < numberOfClasses*this.memberCountOption.getValue();k++)
	        {
	        	this.predictrightclassTPchunk[k]=0;
	        	this.predictclasschunk[k]=0;
	        	this.classNumberschunk[k]=0;
	        	this.recallchunk[k]=0;
	        	this.precisionchunk[k]=0;
	        	this.fscoreschunk[k]=0;
	        	this.sizeofclasseschunk[k]=0;	        	
	        }

	        for (int l=0; l < this.memberCountOption.getValue();l++)
	        {
	        	this.sizefscoredynamicweight[l]=0;
	        }
        }//End if
    }

    /**
     * Predicts a class for an example.
     */
    @Override
    public double[] getVotesForInstance(Instance inst) {
      
    	double[] instanceDistribution = null;
    	double[] count = new double[numberOfClasses];
    	for(int k=0; k<numberOfClasses;k++)
    		count[k]=0;
 		///stable classifier votes
    	instanceDistribution = StableClassifier.getVotesForInstance(inst);
        DoubleVector vote = new DoubleVector(instanceDistribution);
        if (vote.sumOfValues() > 0.0)
        {
            vote.normalize();
            instanceDistribution = vote.getArrayRef();
            for(int k=0; k<numberOfClasses && k < instanceDistribution.length;k++)
            {
                  count[k]=StableWeight.getValue()*instanceDistribution[k];
            }
        }

        instanceDistribution = ensemble[0].getVotesForInstance(inst);
        vote = new DoubleVector(instanceDistribution);
        if (vote.sumOfValues() > 0.0)
        {
            vote.normalize();
            instanceDistribution = vote.getArrayRef();
        	for(int k=0; k<numberOfClasses && k < instanceDistribution.length;k++)
            {
        		count[k]+=dynamicWeight[0]*instanceDistribution[k];
            }
        }
        
        vote = new DoubleVector(count);
        if (vote.sumOfValues() > 0.0)
        {
            vote.normalize();
            count = vote.getArrayRef();
        }
        else
        {
        	for(int k=0; k<numberOfClasses;k++)
        		count[k]=0;
        }  
        return count;
    }

    @Override
    public boolean correctlyClassifies(Instance instance){
		int classlable = (int)instance.classValue();
		double[] count = getVotesForInstance(instance);
        int maxIndex = Utils.maxIndex(count);
	    return classlable==maxIndex;
}
    
    @Override
    public void getModelDescription(StringBuilder out, int indent) {
    }

    /**
     * Adds labeling cost and new threshold to the measurements.
     */
    @Override
    protected Measurement[] getModelMeasurementsImpl() {
    	 List<Measurement> measurementList = new LinkedList<Measurement>();
         measurementList.add(new Measurement("labeling cost", 1.0 *this.costLabeling/this.processedInstances));
         for(int i=0;i<numberOfClasses;i++){
        	 String s = String.valueOf(i);
        	 measurementList.add(new Measurement("F1-scores"+s,this.fscores[i]));
        	 measurementList.add(new Measurement("Recall"+s,this.recall[i]));
        	 measurementList.add(new Measurement("Gmeans"+s,this.gmeans[i]));  
         }
         return measurementList.toArray(new Measurement[measurementList.size()]);
         
    }

    /**
     * Determines whether the classifier is randomizable.
     */
    public boolean isRandomizable() {
        return false;
    }

    @Override
    public Classifier[] getSubClassifiers() {
        return this.ensemble.clone();
    }   
}
